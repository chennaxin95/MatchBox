package edu.cornell.gdiac.physics.ai;

public class CivilianController {

}
