package com.runner.util;

public interface Condition {
    /**
     * Return true when no need to wait
     */
    Boolean check();
}
