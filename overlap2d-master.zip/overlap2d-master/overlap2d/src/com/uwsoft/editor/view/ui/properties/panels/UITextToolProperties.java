package com.uwsoft.editor.view.ui.properties.panels;


/**
 * Created by azakhary on 4/24/15.
 */
public class UITextToolProperties extends UILabelItemProperties {

    public static final String prefix = "com.uwsoft.editor.view.ui.properties.panels.UITextToolProperties";

    public static final String FONT_FAMILY_SELECTED = prefix + ".FONT_FAMILY_SELECTED";

    public UITextToolProperties() {
        super();

    }
}
