package com.uwsoft.editor.utils;

/**
 * Created by azakhary on 7/18/2015.
 */
public class Guide {
    public boolean isVertical;
    public float pos;

    public Guide(boolean isVertical) {
        this.isVertical = isVertical;
    }
}